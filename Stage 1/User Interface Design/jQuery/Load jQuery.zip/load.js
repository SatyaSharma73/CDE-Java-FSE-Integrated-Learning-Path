  if (window.jQuery) {  
    $("#msg").html("jQuery is loaded!!!");
} else {
    
    $("#msg").html("jQuery is not loaded!!!");
}


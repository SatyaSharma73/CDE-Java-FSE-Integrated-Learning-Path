//WRITE YOUR JQUERY CODE HERE
$("#signup_div").hide();


$("#signup").click(function() {
    $("#signup_div").slideDown();
  });
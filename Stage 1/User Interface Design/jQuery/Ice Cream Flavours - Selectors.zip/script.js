// WRITE YOUR CODE HERE

$("p:first").css({"color":"orange"});
$(".flavours").css({
    "background-color":"lightblue",
    "font-size":"120%"
    
});

$("p").css({'color':'orange','font-size':'50%'});
$("ul li:odd").css({'background-color':'orange'});
    $("ul li:even").css({'background-color':'lightblue'});

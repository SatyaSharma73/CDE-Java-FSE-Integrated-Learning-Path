function display() {

    var name = document.getElementById('sname').value;
    var course = document.getElementById('course').value;


    if (name != '') {
        document.getElementById('greet').innerHTML = 'Hi,' + name + '.You have successfully registered for the ' + course + ' course.'
    } else {
        document.getElementById('greet').innerHTML = 'Name cannot be empty';
    }


}

function OrderCake(str) {
	var details=str.match(/[a-z]+|[^a-z]+/gi);
	var weight=details[0];
	var name=details[1];
	var orderNumber=details[2];
	
	var weightKG=Math.round(weight/1000);
	var price=Math.round((weight/1000)*450);
	
	var finalMSG='Your order for '+weightKG+' kg '+name+' cake has been taken. You are requested to pay Rs. '+price+' on the order no '+orderNumber;
	
	return finalMSG;
}
console.log(OrderCake('5848ButterBlast485'));
class Employee 
{
//fill code here
constructor(name, designation, year_of_experience) {
    this.name = name;
    this.designation = designation;
    this.year_of_experience = year_of_experience;
  }

}
function displayEmployee(name,designation,year_of_experience){
    var e = createEmployee(name,designation,year_of_experience);
    return validateObject(e);
    
}

function createEmployee(name, designation, year_of_experience)
{
//fill code here
var emp = new  Employee(name,designation,year_of_experience);
 return emp;
}

function validateObject(employee)
{
//fill code here

if (employee instanceof Employee){
var d = new Date();
var year = (d.getFullYear()-employee.year_of_experience);
ans = employee.name+' is serving the position of '+employee.designation+' since '+year;
return ans;
}
}
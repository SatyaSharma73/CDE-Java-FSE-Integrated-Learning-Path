function wordPlay(number){
    var str='';
   if(number>=1 && number<=50){
       
       for(var i=1;i<=number;i++){
           if(i%3===0 && i%5===0){
                 str=str+' Jump';
           }else if(i%3===0){
                 str=str+' Tap';
           }else if(i%5===0){
               str=str+' Clap';
           }else{
              str=str+' '+i;
           }
       }
   }else if(number<1){
       return 'Not Valid';
   }else{
       return 'Range is High';
   }
   
   return str;
}


console.log(wordPlay(16));

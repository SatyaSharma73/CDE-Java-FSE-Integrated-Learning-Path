select r.rental_id,c.car_id,r.customer_id,r.km_driven
from Rentals r join cars c on r.car_id=c.car_id
where MONTH(r.pickup_date)=8 and YEAR(r.pickup_date)=2019 order by r.rental_id
;
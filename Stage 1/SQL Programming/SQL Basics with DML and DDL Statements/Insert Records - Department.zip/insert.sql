INSERT INTO department (Department_id, Department_name, department_block_number)
VALUES (1,'CSE',3),
(2,'IT',3),
(3,'SE',3);
CREATE or replace PROCEDURE select_city
(
user_id IN number,
city_details OUT varchar
)
AS 
BEGIN
select case
       when city = 'Bangalore'  then
         'User is from Bangalore'
       when city = 'Chennai'    then
         'User is from Chennai'
       else
         'User is from other cities'
     end tmp_status
     
INTO city_details from contact where contact.id=user_id;

end;
/
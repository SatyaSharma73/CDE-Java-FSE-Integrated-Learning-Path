DECLARE 
radius number(5);
area number(7,2);
pi constant number(3,2):=3.14;

BEGIN
radius :=3;
while radius<=7
LOOP
area :=power(radius,2)*pi;
insert into circle values (radius,area);
radius:=radius+1;
end LOOP;
end;
/


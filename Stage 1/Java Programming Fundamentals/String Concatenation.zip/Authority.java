import java.util.*; 

public class Authority{
    
    
    private static void validateString(String s) {
		for(char c:s.toCharArray()) {
			if(!Character.isSpaceChar(c) && !Character.isLetter(c)) {
				 System.out.println("Invalid name");
	                System.exit(0);
			}
		}
	}
	
	
    public static void main (String[] args) {
        Scanner myInput = new Scanner(System.in);
		System.out.println("Inmate's name:");
		String pizzas = myInput.nextLine();

		System.out.println("Inmate's father's name:");
		String puffs = myInput.nextLine();
		
		String finalName = pizzas + " " + puffs;
		validateString(finalName);
		System.out.println(finalName.toUpperCase());
		myInput.close();
    }
}
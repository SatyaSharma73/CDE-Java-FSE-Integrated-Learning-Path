public class Main{
    
    public static void main(String args[]){
        
        Customer customer=new Customer(100,"Satya","satya@sharma.com");
        SavingsAccount savingsaccount = new SavingsAccount(100,customer,27000,5000);
        
        if(savingsaccount.withdraw(10800)){
            System.out.println(savingsaccount.getBalance());
        }
        
    }
}
import java.util.Scanner;
public class Placement {

	public static void main(String[] args) {
	
	Scanner myInput = new Scanner(System.in);
		System.out.println("Enter the no of students placed in CSE:");
		int CSE = myInput.nextInt();
		System.out.println("Enter the no of students placed in ECE:");
		int ECE = myInput.nextInt();
		System.out.println("Enter the no of students placed in MECH:");
		int MECH = myInput.nextInt();

		int max = (CSE > ECE) ? CSE : (ECE > MECH ? ECE : MECH);

		if (CSE < 0 || ECE < 0 || MECH < 0) {
			System.out.println("Input is Invalid");
		} else if (CSE == ECE && ECE == MECH) {
			System.out.println("None of the department has got the highest placement");
		} else {
			if (CSE > ECE && CSE > MECH) {
				System.out.println("Highest placement");
				System.out.println("CSE");
			} else if (ECE > CSE && ECE > MECH) {
				System.out.println("Highest placement");
				System.out.println("ECE");
			} else if (CSE == ECE) {
				System.out.println("Highest placement");
				System.out.println("CSE");
				System.out.println("ECE");
			} else if (ECE == MECH) {
				System.out.println("Highest placement");
				System.out.println("ECE");
				System.out.println("MECH");
			} else if (CSE == MECH) {
				System.out.println("Highest placement");
				System.out.println("CSE");
				System.out.println("MECH");
			}else {
				System.out.println("Highest placement");
				System.out.println("MECH");
			}
		}

}
}

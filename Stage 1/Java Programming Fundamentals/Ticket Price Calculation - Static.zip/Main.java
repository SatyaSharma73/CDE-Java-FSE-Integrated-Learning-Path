
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner cin=new Scanner(System.in);
		System.out.println("Enter no of bookings:");
		int bookings=Integer.parseInt(cin.next());
		
		System.out.println("Enter the available tickets:");
        int availableTickets = Integer.parseInt(cin.next());
		
        Ticket ticket=new Ticket();
        ticket.setAvailableTickets(availableTickets);
        
        for(int i=0;i<bookings;i++) {
        	System.out.println("Enter the ticketid:");
        	int ticketid = Integer.parseInt(cin.next());
        	ticket.setTicketid(ticketid);
        	
        	
        	 System.out.println("Enter the price:");
        	 int price = Integer.parseInt(cin.next());
        	 ticket.setPrice(price);
        	 
        	 
        	 System.out.println("Enter the no of tickets:");
        	 int nooftickets = Integer.parseInt(cin.next());
        	 
        	
        	 System.out.println("Available tickets: " + ticket.getAvailableTickets());
        	 System.out.println("Total Amount: " + ticket.calculateTicketCost(nooftickets));
        	 System.out.println("Available ticket after booking:" + ticket.getAvailableTickets());
        	
        }
	}

}

 grep  "male$" names.txt | cat >> female_nominee.txt

 cat female_nominee.txt

 grep "Male" names.txt | cat >> male_nominee.txt

 cat male_nominee.txt
import java.util.Scanner;
public class AsciValue{
    public static void main (String[] args) {
        Scanner myInput=new Scanner(System.in);
		System.out.println("Enter the digits:");
		int num1=myInput.nextInt();
		int num2=myInput.nextInt();
		int num3=myInput.nextInt();
		int num4=myInput.nextInt();
	
		char first=(char)num1;
		char second=(char)num2;
		char third=(char)num3;
		char fourth=(char)num4;
		
		System.out.println(num1+"-"+first);
		System.out.println(num2+"-"+second);
		System.out.println(num3+"-"+third);
		System.out.println(num4+"-"+fourth);
    }
}
import java.util.*;
public class Division{
    public String divideTwoNumbers(int number1,int number2){
        String result="";
        try{
            int c=number1/number2;
            result="The answer is "+c+".";
        }catch(RuntimeException e){
            result= "Division by zero is not possible.";
        }finally{
            result=result+"Thanks for using the application.";
        }
        
        return result;
    }
    
    public static void main (String[] args) {

     Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the numbers");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();

        Division division = new Division();
        System.out.println(division.divideTwoNumbers(num1, num2));
    }
}
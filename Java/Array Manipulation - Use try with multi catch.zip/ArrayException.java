import java.util.InputMismatchException;
import java.util.Scanner;
public class ArrayException{
    
    
       	 public  String getPriceDetails() {
	        Scanner scanner=new Scanner(System.in);
	        System.out.println("Enter the number of elements in the array");
	        int size=scanner.nextInt();
	        
	        int[] arr=new int[size];
	        System.out.println("Enter the price details");
	        try {
			for (int i = 0; i < size; i++) {
				arr[i] = scanner.nextInt();
			}
		} catch (InputMismatchException e) {
			String s = "Input was not in the correct format";
			return s;
		}
	        
	        System.out.println("Enter the index of the array element you want to access");
	        int index=scanner.nextInt();
	        
	        try{
	             String s="The array element is "+arr[index];
	             return s;
	        }catch(ArrayIndexOutOfBoundsException e){
	        	String s="Array index is out of range";
	           return s;
	        }catch(InputMismatchException e){
	            String s="Input was not in the correct format";
		           return s;
	        }
	        
	        
	    }
	    
	    public static void main (String[] args) {
	        ArrayException exc=new ArrayException();
	        System.out.println(exc.getPriceDetails());
	    }
}
import java.util.Scanner;
public class SnacksDetails{

public static void main (String[] args) {
    
		Scanner myInput=new Scanner(System.in);
		System.out.println("Enter the no of pizzas bought:");
		int pizzas=myInput.nextInt();
		
		System.out.println("Enter the no of puffs bought:");
		int puffs=myInput.nextInt();
		
		System.out.println("Enter the no of cool drinks bought:");
		int cool_drink=myInput.nextInt();
		
		
		System.out.println("Bill Details");
		System.out.println("No of pizzas:"+pizzas);
		System.out.println("No of puffs:"+puffs);
		System.out.println("No of cooldrinks:"+cool_drink);
		int bill=pizzas*100+puffs*20+cool_drink*10;
		System.out.println("Total price="+bill);
		System.out.println("ENJOY THE SHOW!!!");
}
}
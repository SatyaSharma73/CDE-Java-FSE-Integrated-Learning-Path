public class Student {
    
	private int studentId;
	private String studentName, studentAddress, collegeName;
	
	public int getStudentId() {
		return studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public String getStudentAddress() {
		return studentAddress;
	}
	public String getCollegeName() {
		return collegeName;
	}
	
	public Student(int studentid,String studentName,String studentAddress) {
		this.studentId=studentid;
		this.studentName=studentName;
		this.studentAddress=studentAddress;
		this.collegeName="NIT";
	}
	
	public Student(int studentid,String studentName,String studentAddress, String collegeName) {
		this.studentId=studentid;
		this.studentName=studentName;
		this.studentAddress=studentAddress;
		this.collegeName=collegeName;
	}
	
	public void display() {
		System.out.println("Student id:"+this.studentId);
		System.out.println("Student name:"+this.studentName);
		System.out.println("Address:"+this.studentAddress);
		System.out.println("College name:"+this.collegeName);
	}
	
}

import java.util.Scanner;
public class StudentMain {

	public static void main(String[] args) {

		Scanner cin=new Scanner(System.in);
		System.out.println("Enter Student's Id:");
		int studentid=Integer.parseInt(cin.next());
		
		System.out.println("Enter Student's Name:");
		String studentName=cin.next();
		
		System.out.println("Enter Student's address:");
		String studentAddress=cin.next();
		
		
		
	
		while(true) {
			
			System.out.println("Whether the student is from NIT(Yes/No):");
			String answer=cin.next();
			
			if(answer.equalsIgnoreCase("Yes")) {
				Student student=new Student(studentid,studentName,studentAddress);
				student.display();
				break;
			}
			
			else if(answer.equalsIgnoreCase("No")) {
				System.out.println("Enter the college name:");
				String collegeName=cin.next();
				Student student=new Student(studentid,studentName,studentAddress,collegeName);
				student.display();
				break;
			}
			else {
				System.out.println("Wrong Input");
			}
		}
		
		
	}

}

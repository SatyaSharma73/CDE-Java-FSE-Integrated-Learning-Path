public interface CommissionInfo {
       public double calculateCommissionAmount(Ticket ticketObj);
 
 // Fill the code here  
 
}
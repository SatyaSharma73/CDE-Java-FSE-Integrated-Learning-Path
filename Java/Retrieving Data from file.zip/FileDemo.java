import java.io.File;
import java.io.FileReader;
public class FileDemo
{
    public static void main(String[] args) throws Exception
    {
        FileReader fis=null;
		
		fis=new FileReader(new File("log.txt"));
		
		int i;
		while((i=fis.read())!=-1) {
			System.out.print((char)i);
		}
		
    }
}
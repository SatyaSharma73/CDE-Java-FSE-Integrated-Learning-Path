import { TestBed } from '@angular/core/testing';

import { EmployeeService } from './employee.service';

describe('EmployeeService', () => {
  let service: EmployeeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('check getAllEmployees method returns list of emplyees',()=>
  {
    var employees = service.getAllEmployees();
    expect(employees).not.toBeNull();
  });
  it('check getEmployee method returns specific emplyee details',()=>
  {
    var employee = service.getEmployee(2);
    expect(employee).not.toBeNull();
  });
});

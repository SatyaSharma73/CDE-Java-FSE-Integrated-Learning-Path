import { Injectable } from '@angular/core';
import { Employee } from "./employee";
import { department } from "./department";
import { skill } from "./skill";

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }
  departments:department[]=[{id:1,name:"PayRoll"},{id:2,name:"Service"},{id:3,name:"operations"}];
  
  skills:skill[]
=[{id:1,name:"C#"},{id:2,name:"ASP .Net"},{id:3,name:"Sql"},{id:4,name:"Html"}]

  emp1:Employee={id:1,name:"John",salary:10000,permanent:true,dob:new Date('01/14/1998'),dept:this.departments[2],skills:[this.skills[0],this.skills[1]]}

  emp2:Employee={id:2,name:"Smith",salary:5000,permanent:true,dob:new Date('05/04/1997'),dept:this.departments[0],skills:[this.skills[2],this.skills[0]]}

  emp3:Employee={id:3,name:"Mark",salary:5000,permanent:false,dob:new Date('05/14/1999'),dept:this.departments[1],skills:[this.skills[1],this.skills[2]]}

  emp4:Employee={id:2,name:"Mary",salary:50000,permanent:true,dob:new Date('06/04/1996'),dept:this.departments[2],skills:[this.skills[2],this.skills[3]]}

  emp5:Employee={id:2,name:"Smith",salary:50000,permanent:true,dob:new Date('03/09/1995'),dept:this.departments[2],skills:[this.skills[2],this.skills[3]]}


  employeelist:Employee[]=[this.emp1,this.emp2,this.emp3,this.emp4,this.emp5]

  getAllEmployees():Employee[]
  {
    return this.employeelist;
  }
  employee:Employee={id:0,name:"",salary:0,permanent:false,dob:new Date('00/00/0000'),dept:{id:0,name:""},skills:[]};
  getEmployee(employeeId:number):Employee
  {
    
      for (let index = 0; index < this.employeelist.length; index++) {
        if(employeeId==this.employeelist[index].id)
        {
            this.employee=this.employeelist[index];
          
        }
      }
      return this.employee;
  }
}

import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, } from "@angular/common/http";
import { Observable, observable,throwError } from "rxjs";
import { retry,catchError } from "rxjs/operators";
import { User } from "src/IUser";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  
  
  constructor(private http:HttpClient) {
   }
data1:any;
users:any;
  Url:string = "https://reqres.in/api/users?page=2";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })}
  getAllUsers()
  {
      var d= this.http.get(this.Url);
      this.users=d.subscribe(data=>console.log(data));
      console.log(this.data1);
      return d;   
  }
  createUser(user:User)
  {
    return this.http.post<User>(this.Url, JSON.stringify(user), this.httpOptions)
    .pipe(
      retry(1),this.handleError
    )
  }
  updateUser(user:User)
  {
    return this.http.put<User>(this.Url, JSON.stringify(user), this.httpOptions)
    .pipe(
      retry(1),this.handleError)
  }
  deleteuser(user:User)
  {
    return this.http.delete<User>(this.Url, this.httpOptions)
    .pipe(
      retry(1),this.handleError)
  }
  handleError(error:any) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }

  
}

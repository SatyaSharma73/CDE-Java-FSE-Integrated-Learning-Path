export interface department
{
    id:number;
    name:string;
}
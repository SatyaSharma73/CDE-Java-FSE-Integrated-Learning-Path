import {Employee} from "./employee";
function LogEmp(emp:Employee)
{
    console.log(emp);
}

let dept= {id:101,name:"IT"};


let skills = [{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JS"}]
let obj = {id:10,name:"Bhargav",salary:4000,permanent:true,dept,skills};

LogEmp(obj);
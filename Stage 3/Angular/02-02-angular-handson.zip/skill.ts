export interface skill
{
    id:number;
    name:string;

}
import { Employee } from "./employee";
class EmployeeTest
{
    employee:Employee;
    constructor(emp:Employee)
    {
        this.employee = emp;
    }
    Display() {
        return this.employee;
    }
}
let dept= {id:101,name:"IT"};
let skills = [{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JS"}]
let emp = {id:10,name:"Bhargav",salary:4000,permanent:true,dept,skills};

console.log(new EmployeeTest(emp));
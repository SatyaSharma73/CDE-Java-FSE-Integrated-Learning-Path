import { department } from "./department";
import { skill } from "./skill";
export interface Employee
{
    id:number;
    name:string;
    salary:number;
    permanent:boolean;
    dept:department;
    skills:skill[];
}
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ViewEmpComponent } from './view-emp/view-emp.component';
import { EditEmpComponent } from "./edit-emp/edit-emp.component";
import { QuantityIncrementComponent } from "./quantity-increment/quantity-increment.component";
import { QuantitySelectorComponent } from './quantity-selector/quantity-selector.component';

import { EmpEditReactiveComponent } from "./emp-edit-reactive/emp-edit-reactive.component";

import { EmployeeListComponent } from "./employee-list/employee-list.component";

import { EmployeeInfoComponent } from "./employee-list/employee-info/employee-info.component";

const routes: Routes = [{path:'view',component:ViewEmpComponent},
{path:"employee",component:EmployeeDetailsComponent},
{path:"edit",component:EditEmpComponent}
,
{path:"Quantity",component:QuantityIncrementComponent},
{path:"selector",component:QuantitySelectorComponent},
{path:"empReactive",component:EmpEditReactiveComponent},
{path:"employeelist",component:EmployeeListComponent},
{path:'editEmp/:id/:name/:salary',component:EmployeeInfoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }

export const routingComponents = [ViewEmpComponent,EmployeeDetailsComponent,EditEmpComponent,QuantityIncrementComponent,QuantitySelectorComponent,EmpEditReactiveComponent,EmployeeListComponent,EmployeeInfoComponent]

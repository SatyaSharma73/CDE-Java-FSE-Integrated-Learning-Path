import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ViewEmpComponent } from './view-emp/view-emp.component';
import { EditEmpComponent } from "./edit-emp/edit-emp.component";
import { QuantityIncrementComponent } from "./quantity-increment/quantity-increment.component";
import { QuantitySelectorComponent } from './quantity-selector/quantity-selector.component';

const routes: Routes = [{path:'view',component:ViewEmpComponent},
{path:"employee",component:EmployeeDetailsComponent},
{path:"edit",component:EditEmpComponent}
,
{path:"Quantity",component:QuantityIncrementComponent},
{path:"selector",component:QuantitySelectorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [ViewEmpComponent,EmployeeDetailsComponent,EditEmpComponent,QuantityIncrementComponent,QuantitySelectorComponent]

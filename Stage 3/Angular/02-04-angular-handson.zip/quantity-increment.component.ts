import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantity-increment',
  templateUrl: './quantity-increment.component.html',
  styleUrls: ['./quantity-increment.component.css']
})
export class QuantityIncrementComponent implements OnInit {
  msg="";
  onClick()
  {
  this.msg="click me button clicked";
  return this.msg;
  }
num:number=0;
Add()
{
  this.num=++this.num;
  return this.num;
}
  constructor() { }

  ngOnInit(): void {
  }

}

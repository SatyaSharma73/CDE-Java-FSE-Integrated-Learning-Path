import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { EmployeeComponent } from './employee.component';

describe('EmployeeComponent', () => {
  let component: EmployeeComponent;
  let fixture: ComponentFixture<EmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Check title',()=>{
    const fixture = TestBed.createComponent(EmployeeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Employee Information');
  });
  it('check displayId',()=>{
    expect(component.DisplayId).toBeDefined();

  });
  it('check displayName',()=>{
    expect(component.DisplayId).toBeDefined();

  });
  it('check displaySalary',()=>{
    expect(component.DisplayId).toBeDefined();

  });
  it('check DisplayPermanent',()=>{
    expect(component.DisplayId).toBeDefined();

  });

  it('employeeid greater than zero',()=>
  {
    var id = component.DisplayId();
    expect(id).toBeGreaterThan(1000);
  });
  it('Employee name should not be Blank',()=>
  {
    var result = component.DisplayName();
    expect(result).not.toBeNull();

  });
  it('Salary is greater than 3000',()=>{
    expect(component.DisplaySalary()).toBeGreaterThanOrEqual(3000);
  });
  it('check H2 of Id',()=>{
    const fixture = TestBed.createComponent(EmployeeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.id')?.textContent).toContain(1001);


  });
  it('check H2 of Name',()=>{
    const fixture = TestBed.createComponent(EmployeeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.name')?.textContent).toContain("Sam");


  });
  it('check H2 of salary',()=>{
    const fixture = TestBed.createComponent(EmployeeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.sal')?.textContent).toContain(26200);


  });
  it('check H2 of Permanent',()=>{
    const fixture = TestBed.createComponent(EmployeeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.permanent')?.textContent).toContain(false);


  });

});

import { Component, OnInit } from '@angular/core';
import { IEmployee } from "./IEmployee";
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  title = "Employee Information"
   emp:IEmployee={id:1001,name:"Sam",salary:26200,permenant:false};
DisplayId()
{
return this.emp.id;
}
DisplayName()
{
return this.emp.name;
}
DisplaySalary()
{
return this.emp.salary;
}
DisplayPermanentOrNot()
{
return this.emp.permenant;
}
}

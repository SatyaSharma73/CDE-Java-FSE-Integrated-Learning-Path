import { Component, OnInit } from '@angular/core';
import { Employee } from "./employee";
import { skill } from "./skill";
import { department } from "./department";
import { ActivatedRoute } from "@angular/router";
import { PropertyRead } from '@angular/compiler';

let dept:department;
dept = {
  id:2,
  name:"IT"
}

let skills :skill[];
skills = [{
  id:1,
  name:"Java"
},{
  id:2,
  name:"CSS"
}]
let emp :Employee;
emp = {
  id:1,
  name:"John",
  dob:new Date('12/05/2000'),
  salary:50000,
  permanent:false,
  dept,
  skills
}

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})

export class EmployeeDetailsComponent implements OnInit {
  
  employee = emp;
  constructor() { }

  ngOnInit(): void {
  }

}

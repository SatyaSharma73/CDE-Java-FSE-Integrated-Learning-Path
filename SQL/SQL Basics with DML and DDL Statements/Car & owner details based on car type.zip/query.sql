select car_id, car_name,owner_id from CARS where car_type="Hatchback" or car_type="SUV" order by car_id;

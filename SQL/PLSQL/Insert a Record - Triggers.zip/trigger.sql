CREATE or replace TRIGGER trig_aff
after INSERT 
ON Employee

begin 
 dbms_output.put_line('NEW EMPLOYEE DETAILS INSERTED');
  end;
  /

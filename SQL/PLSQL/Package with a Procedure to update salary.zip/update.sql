CREATE or REPLACE package EMP_DESIGNATION 
AS procedure EMP_DETAILS(
deg employee.designation%TYPE,
incentive IN number
);
END EMP_DESIGNATION;
/

CREATE or REPLACE package BODY EMP_DESIGNATION AS
procedure EMP_DETAILS(
deg IN employee.designation%TYPE,
incentive IN number
)
IS BEGIN

UPDATE employee SET employee.salary=employee.salary+incentive where employee.designation=deg;

 dbms_output.put_line(SQL%ROWCOUNT || ' employee(s) are updated.');
  END EMP_DETAILS;
END;
/
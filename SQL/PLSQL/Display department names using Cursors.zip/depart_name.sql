-- set serveroutput on  Helps to display the output when it is compiled or executed 
set serveroutput on
DECLARE 
BEGIN
dbms_output.put_line('Department Names are:');
for rec IN( select Department_name from Department order by Department_name )
LOOP
dbms_output.put_line(rec.DEPARTMENT_NAME);
end LOOP;
end;
/
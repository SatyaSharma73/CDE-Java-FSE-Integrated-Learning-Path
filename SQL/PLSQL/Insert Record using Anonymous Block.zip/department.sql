BEGIN

Insert into department(department_id,department_name,location_id) 
select max(department_id)+10,'TESTING','CHN-102' from department;



END;
/
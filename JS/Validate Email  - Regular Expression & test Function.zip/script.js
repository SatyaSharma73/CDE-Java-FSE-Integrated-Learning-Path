function validateEmail(email) {

   var pattern = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
   
  if(email.match(pattern)){
      return "Valid email address!";
  }else{
    return "Invalid email address!"; 
  }
    
    
}
console.log(validateEmail('info123@example.com'));
console.log(validateEmail('abc-defmail.com'));
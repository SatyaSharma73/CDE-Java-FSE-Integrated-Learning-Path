function modifyString(str)
{
    var newString=str.split(/\s/).join('');
    newString=newString.toLowerCase();
    
    return newString;
}

function uniqueCharacters(str)
{
    var str1=modifyString(str);
 var uniql="";
 for (var x=0;x < str1.length;x++)
 {

 if(uniql.indexOf(str1.charAt(x))==-1)
  {
  uniql += str1[x];  
  
   }
  }
    return uniql;
}  

console.log(uniqueCharacters("Welcome to the Javascript course"));
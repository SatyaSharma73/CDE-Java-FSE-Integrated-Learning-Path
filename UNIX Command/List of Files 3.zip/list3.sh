#provide the option to list the contents of the current directories in comma seperated fashion
ls -m
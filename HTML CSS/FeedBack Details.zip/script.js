var arr1 = [];

function addFeedback() {
    var feed = document.getElementById("feedback").value;
    arr1.push(feed);
    document.getElementById("feedback").value = "";
    document.getElementById("result").innerHTML = "<h2>" + "Feedback Details " + "</h2>" + "Successfully Added Feedback Details!";
}


function displayFeedback() {
    var count = 1;
    var op = "<h2>Feedback Details</h2>";
    for (var index in arr1) {

        op = op + "Feedback " + (count++) + "<br>" + arr1[index] + "<br>";
    }
    document.getElementById("result").innerHTML = op;
}

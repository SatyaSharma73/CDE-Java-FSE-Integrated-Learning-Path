package com.cts.bank.exception;

public class AccountTransactionException extends Exception {

	public AccountTransactionException() {
		super();
	}

	public AccountTransactionException(String message) {
		super(message);
	}
	
}